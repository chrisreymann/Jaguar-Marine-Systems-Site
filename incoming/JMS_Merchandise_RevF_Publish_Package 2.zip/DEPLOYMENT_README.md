# Jaguar Marine Systems — Rev F storefront deployment

This package preserves the four **approved** T-shirt previews from the user-selected storefront reference, rather than substituting regenerated drawings.

### Deploy to GitHub Pages
1. Extract the ZIP.
2. In the repository `chrisreymann/Jaguar-Marine-Systems-Site`, upload **merchandise.html** to the repo root, replacing the existing merchandise.html.
3. Upload the entire `assets/merchandise/` folder (or its six files) to the identical path in the repository.
4. Confirm the main `assets/jaguar-logo.webp` already exists.
5. Open the website's merchandise URL with a cache-busting query string, e.g. `?v=revf`, and inspect all four images on desktop and mobile.

This ZIP is **not yet published**. The available GitHub connector can write text but cannot ingest the image bytes from the local working container, so we have not altered the live website.

### Artwork quality gate
The four mockup crops are only ~362–387 pixels wide. They are suitable for small web previews but are NOT transparent standalone print graphics. No print-ready or vector claim is made. For Printify, obtain or recreate underlying isolated art at supplier-specific final size and inspect on samples.

Do not replace the official Jaguar Marine Systems logo in `assets/jaguar-logo.webp`.
